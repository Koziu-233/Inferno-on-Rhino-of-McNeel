import os
from time import time

#----------///Method declarations///----------
def add_to_receiver(dict, idx, timestamp, txt, threshold):
    irr = float(txt)
    #---///Add data to the dictionary///---
    if idx in dict.keys():
        if irr > dict[idx]['max']:
            dict[idx]['max'] = irr
        if irr >= threshold:
            dict[idx].update({timestamp: irr})
    else:
        if irr >= threshold:
            dict[idx] = {'max': irr, timestamp: irr}
        else:
            dict[idx] = {'max': irr}
    return dict

#----------///Main method///----------

#----------///Main///----------
if __name__ == '__main__':
    #---///Get all file names in current folder///---
    File_Names = []
    for root, dirs, files in os.walk(os.getcwd()):
        for file_name in files:
            if file_name.find("Result_") != -1 and file_name.find(".txt") != -1:
                File_Names.append(file_name)
    works_to_do = len(File_Names)

    #---///Create the dictionary///---
    dict = {}
    start_all = time()

    #---///Read the txt files///---
    for idx_work, path in enumerate(File_Names):
        start_sub = time()
        with open(path, 'r') as file:
            Lst_irr = file.readlines()
        
        #Get the timestamp
        Lst_date = path.split('_')
        mm = Lst_date[1]
        dd = Lst_date[2]
        hh = Lst_date[3].replace('.txt', '')
        mimi = Lst_date[4].replace('.txt', '')
        timestamp = '_'.join([mm, dd, hh, mimi])
        
        #Fill in the information
        for idx_face, txt_irr in enumerate(Lst_irr):
            dict = add_to_receiver(dict, idx_face, timestamp, txt_irr, 2500.0) #<====================================Change the threshold here!!!=====================================<<<
        
        finish_sub = time()
        print('\r' + f'Used {round(finish_sub - start_sub, 2)} seconds, completed works: {idx_work + 1} / {works_to_do}')
    
    #---///Finish and write the results///---
    finish_all = time()
    print(f'Finished in {round(finish_all - start_all, 2)} seconds! Now writing...')
    path_write = 'Annual_Index.txt'
    with open(path_write, 'w') as file:
        for idx_panel in dict.keys():
            max_energy = dict[idx_panel].pop('max')
            Lst_write = [str(max_energy)]
            if dict[idx_panel].keys():
                for timestamp in dict[idx_panel].keys():
                    Lst_write.append(timestamp + ' ' + str(dict[idx_panel][timestamp]))
            txt_write = ';'.join(Lst_write)
            file.write(txt_write + '\n')
        print(f'Data successfully writen to {path_write}! All jobs done, good luck!')
